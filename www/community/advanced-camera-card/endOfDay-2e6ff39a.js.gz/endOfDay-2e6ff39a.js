import{d7 as r}from"./card-082b91a0.js";function o(o){const s=r(o);return s.setHours(23,59,59,999),s}export{o as e};
