/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
function t(t,e,i,o){var s,n=arguments.length,r=n<3?e:null===o?o=Object.getOwnPropertyDescriptor(e,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(t,e,i,o);else for(var a=t.length-1;a>=0;a--)(s=t[a])&&(r=(n<3?s(r):n>3?s(e,i,r):s(e,i))||r);return n>3&&r&&Object.defineProperty(e,i,r),r
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */}const e=window,i=e.ShadowRoot&&(void 0===e.ShadyCSS||e.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,o=Symbol(),s=new WeakMap;class n{constructor(t,e,i){if(this._$cssResult$=!0,i!==o)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o;const e=this.t;if(i&&void 0===t){const i=void 0!==e&&1===e.length;i&&(t=s.get(e)),void 0===t&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),i&&s.set(e,t))}return t}toString(){return this.cssText}}const r=(t,...e)=>{const i=1===t.length?t[0]:e.reduce(((e,i,o)=>e+(t=>{if(!0===t._$cssResult$)return t.cssText;if("number"==typeof t)return t;throw Error("Value passed to 'css' function must be a 'css' function result: "+t+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+t[o+1]),t[0]);return new n(i,t,o)},a=i?t=>t:t=>t instanceof CSSStyleSheet?(t=>{let e="";for(const i of t.cssRules)e+=i.cssText;return(t=>new n("string"==typeof t?t:t+"",void 0,o))(e)})(t):t
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */;var l;const c=window,h=c.trustedTypes,d=h?h.emptyScript:"",u=c.reactiveElementPolyfillSupport,p={toAttribute(t,e){switch(e){case Boolean:t=t?d:null;break;case Object:case Array:t=null==t?t:JSON.stringify(t)}return t},fromAttribute(t,e){let i=t;switch(e){case Boolean:i=null!==t;break;case Number:i=null===t?null:Number(t);break;case Object:case Array:try{i=JSON.parse(t)}catch(t){i=null}}return i}},m=(t,e)=>e!==t&&(e==e||t==t),_={attribute:!0,type:String,converter:p,reflect:!1,hasChanged:m};class f extends HTMLElement{constructor(){super(),this._$Ei=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$El=null,this.u()}static addInitializer(t){var e;this.finalize(),(null!==(e=this.h)&&void 0!==e?e:this.h=[]).push(t)}static get observedAttributes(){this.finalize();const t=[];return this.elementProperties.forEach(((e,i)=>{const o=this._$Ep(i,e);void 0!==o&&(this._$Ev.set(o,i),t.push(o))})),t}static createProperty(t,e=_){if(e.state&&(e.attribute=!1),this.finalize(),this.elementProperties.set(t,e),!e.noAccessor&&!this.prototype.hasOwnProperty(t)){const i="symbol"==typeof t?Symbol():"__"+t,o=this.getPropertyDescriptor(t,i,e);void 0!==o&&Object.defineProperty(this.prototype,t,o)}}static getPropertyDescriptor(t,e,i){return{get(){return this[e]},set(o){const s=this[t];this[e]=o,this.requestUpdate(t,s,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)||_}static finalize(){if(this.hasOwnProperty("finalized"))return!1;this.finalized=!0;const t=Object.getPrototypeOf(this);if(t.finalize(),void 0!==t.h&&(this.h=[...t.h]),this.elementProperties=new Map(t.elementProperties),this._$Ev=new Map,this.hasOwnProperty("properties")){const t=this.properties,e=[...Object.getOwnPropertyNames(t),...Object.getOwnPropertySymbols(t)];for(const i of e)this.createProperty(i,t[i])}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(t){const e=[];if(Array.isArray(t)){const i=new Set(t.flat(1/0).reverse());for(const t of i)e.unshift(a(t))}else void 0!==t&&e.push(a(t));return e}static _$Ep(t,e){const i=e.attribute;return!1===i?void 0:"string"==typeof i?i:"string"==typeof t?t.toLowerCase():void 0}u(){var t;this._$E_=new Promise((t=>this.enableUpdating=t)),this._$AL=new Map,this._$Eg(),this.requestUpdate(),null===(t=this.constructor.h)||void 0===t||t.forEach((t=>t(this)))}addController(t){var e,i;(null!==(e=this._$ES)&&void 0!==e?e:this._$ES=[]).push(t),void 0!==this.renderRoot&&this.isConnected&&(null===(i=t.hostConnected)||void 0===i||i.call(t))}removeController(t){var e;null===(e=this._$ES)||void 0===e||e.splice(this._$ES.indexOf(t)>>>0,1)}_$Eg(){this.constructor.elementProperties.forEach(((t,e)=>{this.hasOwnProperty(e)&&(this._$Ei.set(e,this[e]),delete this[e])}))}createRenderRoot(){var t;const o=null!==(t=this.shadowRoot)&&void 0!==t?t:this.attachShadow(this.constructor.shadowRootOptions);return((t,o)=>{i?t.adoptedStyleSheets=o.map((t=>t instanceof CSSStyleSheet?t:t.styleSheet)):o.forEach((i=>{const o=document.createElement("style"),s=e.litNonce;void 0!==s&&o.setAttribute("nonce",s),o.textContent=i.cssText,t.appendChild(o)}))})(o,this.constructor.elementStyles),o}connectedCallback(){var t;void 0===this.renderRoot&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),null===(t=this._$ES)||void 0===t||t.forEach((t=>{var e;return null===(e=t.hostConnected)||void 0===e?void 0:e.call(t)}))}enableUpdating(t){}disconnectedCallback(){var t;null===(t=this._$ES)||void 0===t||t.forEach((t=>{var e;return null===(e=t.hostDisconnected)||void 0===e?void 0:e.call(t)}))}attributeChangedCallback(t,e,i){this._$AK(t,i)}_$EO(t,e,i=_){var o;const s=this.constructor._$Ep(t,i);if(void 0!==s&&!0===i.reflect){const n=(void 0!==(null===(o=i.converter)||void 0===o?void 0:o.toAttribute)?i.converter:p).toAttribute(e,i.type);this._$El=t,null==n?this.removeAttribute(s):this.setAttribute(s,n),this._$El=null}}_$AK(t,e){var i;const o=this.constructor,s=o._$Ev.get(t);if(void 0!==s&&this._$El!==s){const t=o.getPropertyOptions(s),n="function"==typeof t.converter?{fromAttribute:t.converter}:void 0!==(null===(i=t.converter)||void 0===i?void 0:i.fromAttribute)?t.converter:p;this._$El=s,this[s]=n.fromAttribute(e,t.type),this._$El=null}}requestUpdate(t,e,i){let o=!0;void 0!==t&&(((i=i||this.constructor.getPropertyOptions(t)).hasChanged||m)(this[t],e)?(this._$AL.has(t)||this._$AL.set(t,e),!0===i.reflect&&this._$El!==t&&(void 0===this._$EC&&(this._$EC=new Map),this._$EC.set(t,i))):o=!1),!this.isUpdatePending&&o&&(this._$E_=this._$Ej())}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_}catch(t){Promise.reject(t)}const t=this.scheduleUpdate();return null!=t&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var t;if(!this.isUpdatePending)return;this.hasUpdated,this._$Ei&&(this._$Ei.forEach(((t,e)=>this[e]=t)),this._$Ei=void 0);let e=!1;const i=this._$AL;try{e=this.shouldUpdate(i),e?(this.willUpdate(i),null===(t=this._$ES)||void 0===t||t.forEach((t=>{var e;return null===(e=t.hostUpdate)||void 0===e?void 0:e.call(t)})),this.update(i)):this._$Ek()}catch(t){throw e=!1,this._$Ek(),t}e&&this._$AE(i)}willUpdate(t){}_$AE(t){var e;null===(e=this._$ES)||void 0===e||e.forEach((t=>{var e;return null===(e=t.hostUpdated)||void 0===e?void 0:e.call(t)})),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(t){return!0}update(t){void 0!==this._$EC&&(this._$EC.forEach(((t,e)=>this._$EO(e,this[e],t))),this._$EC=void 0),this._$Ek()}updated(t){}firstUpdated(t){}}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var g;f.finalized=!0,f.elementProperties=new Map,f.elementStyles=[],f.shadowRootOptions={mode:"open"},null==u||u({ReactiveElement:f}),(null!==(l=c.reactiveElementVersions)&&void 0!==l?l:c.reactiveElementVersions=[]).push("1.6.0");const v=window,y=v.trustedTypes,b=y?y.createPolicy("lit-html",{createHTML:t=>t}):void 0,$=`lit$${(Math.random()+"").slice(9)}$`,w="?"+$,C=`<${w}>`,A=document,S=(t="")=>A.createComment(t),I=t=>null===t||"object"!=typeof t&&"function"!=typeof t,x=Array.isArray,E=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,k=/-->/g,T=/>/g,U=RegExp(">|[ \t\n\f\r](?:([^\\s\"'>=/]+)([ \t\n\f\r]*=[ \t\n\f\r]*(?:[^ \t\n\f\r\"'`<>=]|(\"|')|))|$)","g"),D=/'/g,F=/"/g,P=/^(?:script|style|textarea|title)$/i,M=(t=>(e,...i)=>({_$litType$:t,strings:e,values:i}))(1),N=Symbol.for("lit-noChange"),O=Symbol.for("lit-nothing"),R=new WeakMap,V=A.createTreeWalker(A,129,null,!1);class H{constructor({strings:t,_$litType$:e},i){let o;this.parts=[];let s=0,n=0;const r=t.length-1,a=this.parts,[l,c]=((t,e)=>{const i=t.length-1,o=[];let s,n=2===e?"<svg>":"",r=E;for(let e=0;e<i;e++){const i=t[e];let a,l,c=-1,h=0;for(;h<i.length&&(r.lastIndex=h,l=r.exec(i),null!==l);)h=r.lastIndex,r===E?"!--"===l[1]?r=k:void 0!==l[1]?r=T:void 0!==l[2]?(P.test(l[2])&&(s=RegExp("</"+l[2],"g")),r=U):void 0!==l[3]&&(r=U):r===U?">"===l[0]?(r=null!=s?s:E,c=-1):void 0===l[1]?c=-2:(c=r.lastIndex-l[2].length,a=l[1],r=void 0===l[3]?U:'"'===l[3]?F:D):r===F||r===D?r=U:r===k||r===T?r=E:(r=U,s=void 0);const d=r===U&&t[e+1].startsWith("/>")?" ":"";n+=r===E?i+C:c>=0?(o.push(a),i.slice(0,c)+"$lit$"+i.slice(c)+$+d):i+$+(-2===c?(o.push(void 0),e):d)}const a=n+(t[i]||"<?>")+(2===e?"</svg>":"");if(!Array.isArray(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return[void 0!==b?b.createHTML(a):a,o]})(t,e);if(this.el=H.createElement(l,i),V.currentNode=this.el.content,2===e){const t=this.el.content,e=t.firstChild;e.remove(),t.append(...e.childNodes)}for(;null!==(o=V.nextNode())&&a.length<r;){if(1===o.nodeType){if(o.hasAttributes()){const t=[];for(const e of o.getAttributeNames())if(e.endsWith("$lit$")||e.startsWith($)){const i=c[n++];if(t.push(e),void 0!==i){const t=o.getAttribute(i.toLowerCase()+"$lit$").split($),e=/([.?@])?(.*)/.exec(i);a.push({type:1,index:s,name:e[2],strings:t,ctor:"."===e[1]?G:"?"===e[1]?q:"@"===e[1]?W:B})}else a.push({type:6,index:s})}for(const e of t)o.removeAttribute(e)}if(P.test(o.tagName)){const t=o.textContent.split($),e=t.length-1;if(e>0){o.textContent=y?y.emptyScript:"";for(let i=0;i<e;i++)o.append(t[i],S()),V.nextNode(),a.push({type:2,index:++s});o.append(t[e],S())}}}else if(8===o.nodeType)if(o.data===w)a.push({type:2,index:s});else{let t=-1;for(;-1!==(t=o.data.indexOf($,t+1));)a.push({type:7,index:s}),t+=$.length-1}s++}}static createElement(t,e){const i=A.createElement("template");return i.innerHTML=t,i}}function L(t,e,i=t,o){var s,n,r,a;if(e===N)return e;let l=void 0!==o?null===(s=i._$Co)||void 0===s?void 0:s[o]:i._$Cl;const c=I(e)?void 0:e._$litDirective$;return(null==l?void 0:l.constructor)!==c&&(null===(n=null==l?void 0:l._$AO)||void 0===n||n.call(l,!1),void 0===c?l=void 0:(l=new c(t),l._$AT(t,i,o)),void 0!==o?(null!==(r=(a=i)._$Co)&&void 0!==r?r:a._$Co=[])[o]=l:i._$Cl=l),void 0!==l&&(e=L(t,l._$AS(t,e.values),l,o)),e}class j{constructor(t,e){this.u=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}v(t){var e;const{el:{content:i},parts:o}=this._$AD,s=(null!==(e=null==t?void 0:t.creationScope)&&void 0!==e?e:A).importNode(i,!0);V.currentNode=s;let n=V.nextNode(),r=0,a=0,l=o[0];for(;void 0!==l;){if(r===l.index){let e;2===l.type?e=new z(n,n.nextSibling,this,t):1===l.type?e=new l.ctor(n,l.name,l.strings,this,t):6===l.type&&(e=new Y(n,this,t)),this.u.push(e),l=o[++a]}r!==(null==l?void 0:l.index)&&(n=V.nextNode(),r++)}return s}p(t){let e=0;for(const i of this.u)void 0!==i&&(void 0!==i.strings?(i._$AI(t,i,e),e+=i.strings.length-2):i._$AI(t[e])),e++}}class z{constructor(t,e,i,o){var s;this.type=2,this._$AH=O,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=i,this.options=o,this._$Cm=null===(s=null==o?void 0:o.isConnected)||void 0===s||s}get _$AU(){var t,e;return null!==(e=null===(t=this._$AM)||void 0===t?void 0:t._$AU)&&void 0!==e?e:this._$Cm}get parentNode(){let t=this._$AA.parentNode;const e=this._$AM;return void 0!==e&&11===t.nodeType&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=L(this,t,e),I(t)?t===O||null==t||""===t?(this._$AH!==O&&this._$AR(),this._$AH=O):t!==this._$AH&&t!==N&&this.g(t):void 0!==t._$litType$?this.$(t):void 0!==t.nodeType?this.T(t):(t=>x(t)||"function"==typeof(null==t?void 0:t[Symbol.iterator]))(t)?this.k(t):this.g(t)}O(t,e=this._$AB){return this._$AA.parentNode.insertBefore(t,e)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}g(t){this._$AH!==O&&I(this._$AH)?this._$AA.nextSibling.data=t:this.T(A.createTextNode(t)),this._$AH=t}$(t){var e;const{values:i,_$litType$:o}=t,s="number"==typeof o?this._$AC(t):(void 0===o.el&&(o.el=H.createElement(o.h,this.options)),o);if((null===(e=this._$AH)||void 0===e?void 0:e._$AD)===s)this._$AH.p(i);else{const t=new j(s,this),e=t.v(this.options);t.p(i),this.T(e),this._$AH=t}}_$AC(t){let e=R.get(t.strings);return void 0===e&&R.set(t.strings,e=new H(t)),e}k(t){x(this._$AH)||(this._$AH=[],this._$AR());const e=this._$AH;let i,o=0;for(const s of t)o===e.length?e.push(i=new z(this.O(S()),this.O(S()),this,this.options)):i=e[o],i._$AI(s),o++;o<e.length&&(this._$AR(i&&i._$AB.nextSibling,o),e.length=o)}_$AR(t=this._$AA.nextSibling,e){var i;for(null===(i=this._$AP)||void 0===i||i.call(this,!1,!0,e);t&&t!==this._$AB;){const e=t.nextSibling;t.remove(),t=e}}setConnected(t){var e;void 0===this._$AM&&(this._$Cm=t,null===(e=this._$AP)||void 0===e||e.call(this,t))}}class B{constructor(t,e,i,o,s){this.type=1,this._$AH=O,this._$AN=void 0,this.element=t,this.name=e,this._$AM=o,this.options=s,i.length>2||""!==i[0]||""!==i[1]?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=O}get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}_$AI(t,e=this,i,o){const s=this.strings;let n=!1;if(void 0===s)t=L(this,t,e,0),n=!I(t)||t!==this._$AH&&t!==N,n&&(this._$AH=t);else{const o=t;let r,a;for(t=s[0],r=0;r<s.length-1;r++)a=L(this,o[i+r],e,r),a===N&&(a=this._$AH[r]),n||(n=!I(a)||a!==this._$AH[r]),a===O?t=O:t!==O&&(t+=(null!=a?a:"")+s[r+1]),this._$AH[r]=a}n&&!o&&this.j(t)}j(t){t===O?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,null!=t?t:"")}}class G extends B{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===O?void 0:t}}const K=y?y.emptyScript:"";class q extends B{constructor(){super(...arguments),this.type=4}j(t){t&&t!==O?this.element.setAttribute(this.name,K):this.element.removeAttribute(this.name)}}class W extends B{constructor(t,e,i,o,s){super(t,e,i,o,s),this.type=5}_$AI(t,e=this){var i;if((t=null!==(i=L(this,t,e,0))&&void 0!==i?i:O)===N)return;const o=this._$AH,s=t===O&&o!==O||t.capture!==o.capture||t.once!==o.once||t.passive!==o.passive,n=t!==O&&(o===O||s);s&&this.element.removeEventListener(this.name,this,o),n&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){var e,i;"function"==typeof this._$AH?this._$AH.call(null!==(i=null===(e=this.options)||void 0===e?void 0:e.host)&&void 0!==i?i:this.element,t):this._$AH.handleEvent(t)}}class Y{constructor(t,e,i){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(t){L(this,t)}}const Z=v.litHtmlPolyfillSupport;null==Z||Z(H,z),(null!==(g=v.litHtmlVersions)&&void 0!==g?g:v.litHtmlVersions=[]).push("2.6.1");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var J,X;class Q extends f{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var t,e;const i=super.createRenderRoot();return null!==(t=(e=this.renderOptions).renderBefore)&&void 0!==t||(e.renderBefore=i.firstChild),i}update(t){const e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=((t,e,i)=>{var o,s;const n=null!==(o=null==i?void 0:i.renderBefore)&&void 0!==o?o:e;let r=n._$litPart$;if(void 0===r){const t=null!==(s=null==i?void 0:i.renderBefore)&&void 0!==s?s:null;n._$litPart$=r=new z(e.insertBefore(S(),t),t,void 0,null!=i?i:{})}return r._$AI(t),r})(e,this.renderRoot,this.renderOptions)}connectedCallback(){var t;super.connectedCallback(),null===(t=this._$Do)||void 0===t||t.setConnected(!0)}disconnectedCallback(){var t;super.disconnectedCallback(),null===(t=this._$Do)||void 0===t||t.setConnected(!1)}render(){return N}}Q.finalized=!0,Q._$litElement$=!0,null===(J=globalThis.litElementHydrateSupport)||void 0===J||J.call(globalThis,{LitElement:Q});const tt=globalThis.litElementPolyfillSupport;null==tt||tt({LitElement:Q}),(null!==(X=globalThis.litElementVersions)&&void 0!==X?X:globalThis.litElementVersions=[]).push("3.2.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const et=t=>e=>"function"==typeof e?((t,e)=>(customElements.define(t,e),e))(t,e):((t,e)=>{const{kind:i,elements:o}=e;return{kind:i,elements:o,finisher(e){customElements.define(t,e)}}})(t,e)
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */,it=(t,e)=>"method"===e.kind&&e.descriptor&&!("value"in e.descriptor)?{...e,finisher(i){i.createProperty(e.key,t)}}:{kind:"field",key:Symbol(),placement:"own",descriptor:{},originalKey:e.key,initializer(){"function"==typeof e.initializer&&(this[e.key]=e.initializer.call(this))},finisher(i){i.createProperty(e.key,t)}};function ot(t){return(e,i)=>void 0!==i?((t,e,i)=>{e.constructor.createProperty(i,t)})(t,e,i):it(t,e)
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */}function st(t){return ot({...t,state:!0})}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var nt;null===(nt=window.HTMLSlotElement)||void 0===nt||nt.prototype.assignedElements;var rt,at,lt=function(t,e){return ct(e).format(t)},ct=function(t){return new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric"})};!function(t){t.language="language",t.system="system",t.comma_decimal="comma_decimal",t.decimal_comma="decimal_comma",t.space_comma="space_comma",t.none="none"}(rt||(rt={})),function(t){t.language="language",t.system="system",t.am_pm="12",t.twenty_four="24"}(at||(at={}));var ht=function(t){if(t.time_format===at.language||t.time_format===at.system){var e=t.time_format===at.language?t.language:void 0,i=(new Date).toLocaleString(e);return i.includes("AM")||i.includes("PM")}return t.time_format===at.am_pm},dt=function(t,e){return ut(e).format(t)},ut=function(t){return new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric",hour:ht(t)?"numeric":"2-digit",minute:"2-digit",hour12:ht(t)})},pt=function(t,e){return mt(e).format(t)},mt=function(t){return new Intl.DateTimeFormat(t.language,{hour:"numeric",minute:"2-digit",hour12:ht(t)})};function _t(){return(_t=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var i=arguments[e];for(var o in i)Object.prototype.hasOwnProperty.call(i,o)&&(t[o]=i[o])}return t}).apply(this,arguments)}function ft(t){return t.substr(0,t.indexOf("."))}var gt=function(t,e,i){var o=e?function(t){switch(t.number_format){case rt.comma_decimal:return["en-US","en"];case rt.decimal_comma:return["de","es","it"];case rt.space_comma:return["fr","sv","cs"];case rt.system:return;default:return t.language}}(e):void 0;if(Number.isNaN=Number.isNaN||function t(e){return"number"==typeof e&&t(e)},(null==e?void 0:e.number_format)!==rt.none&&!Number.isNaN(Number(t))&&Intl)try{return new Intl.NumberFormat(o,vt(t,i)).format(Number(t))}catch(e){return console.error(e),new Intl.NumberFormat(void 0,vt(t,i)).format(Number(t))}return"string"==typeof t?t:function(t,e){return void 0===e&&(e=2),Math.round(t*Math.pow(10,e))/Math.pow(10,e)}(t,null==i?void 0:i.maximumFractionDigits).toString()+("currency"===(null==i?void 0:i.style)?" "+i.currency:"")},vt=function(t,e){var i=_t({maximumFractionDigits:2},e);if("string"!=typeof t)return i;if(!e||!e.minimumFractionDigits&&!e.maximumFractionDigits){var o=t.indexOf(".")>-1?t.split(".")[1].length:0;i.minimumFractionDigits=o,i.maximumFractionDigits=o}return i},yt=function(t,e,i,o){var s=void 0!==o?o:e.state;if("unknown"===s||"unavailable"===s)return t("state.default."+s);if(function(t){return!!t.attributes.unit_of_measurement||!!t.attributes.state_class}(e)){if("monetary"===e.attributes.device_class)try{return gt(s,i,{style:"currency",currency:e.attributes.unit_of_measurement})}catch(t){}return gt(s,i)+(e.attributes.unit_of_measurement?" "+e.attributes.unit_of_measurement:"")}var n=function(t){return ft(t.entity_id)}(e);if("input_datetime"===n){var r;if(void 0===o)return e.attributes.has_date&&e.attributes.has_time?(r=new Date(e.attributes.year,e.attributes.month-1,e.attributes.day,e.attributes.hour,e.attributes.minute),dt(r,i)):e.attributes.has_date?(r=new Date(e.attributes.year,e.attributes.month-1,e.attributes.day),lt(r,i)):e.attributes.has_time?((r=new Date).setHours(e.attributes.hour,e.attributes.minute),pt(r,i)):e.state;try{var a=o.split(" ");if(2===a.length)return dt(new Date(a.join("T")),i);if(1===a.length){if(o.includes("-"))return lt(new Date(o+"T00:00"),i);if(o.includes(":")){var l=new Date;return pt(new Date(l.toISOString().split("T")[0]+"T"+o),i)}}return o}catch(t){return o}}return"humidifier"===n&&"on"===s&&e.attributes.humidity?e.attributes.humidity+" %":"counter"===n||"number"===n||"input_number"===n?gt(s,i):e.attributes.device_class&&t("component."+n+".state."+e.attributes.device_class+"."+s)||t("component."+n+".state._."+s)||s},bt=["closed","locked","off"],$t=function(t,e,i,o){o=o||{},i=null==i?{}:i;var s=new Event(e,{bubbles:void 0===o.bubbles||o.bubbles,cancelable:Boolean(o.cancelable),composed:void 0===o.composed||o.composed});return s.detail=i,t.dispatchEvent(s),s},wt=function(t){$t(window,"haptic",t)},Ct=function(t,e){return function(t,e,i){void 0===i&&(i=!0);var o,s=ft(e),n="group"===s?"homeassistant":s;switch(s){case"lock":o=i?"unlock":"lock";break;case"cover":o=i?"open_cover":"close_cover";break;default:o=i?"turn_on":"turn_off"}return t.callService(n,o,{entity_id:e})}(t,e,bt.includes(t.states[e].state))},At=function(t,e,i,o){if(o||(o={action:"more-info"}),!o.confirmation||o.confirmation.exemptions&&o.confirmation.exemptions.some((function(t){return t.user===e.user.id}))||(wt("warning"),confirm(o.confirmation.text||"Are you sure you want to "+o.action+"?")))switch(o.action){case"more-info":(i.entity||i.camera_image)&&$t(t,"hass-more-info",{entityId:i.entity?i.entity:i.camera_image});break;case"navigate":o.navigation_path&&function(t,e,i){void 0===i&&(i=!1),i?history.replaceState(null,"",e):history.pushState(null,"",e),$t(window,"location-changed",{replace:i})}(0,o.navigation_path);break;case"url":o.url_path&&window.open(o.url_path);break;case"toggle":i.entity&&(Ct(e,i.entity),wt("success"));break;case"call-service":if(!o.service)return void wt("failure");var s=o.service.split(".",2);e.callService(s[0],s[1],o.service_data,o.target),wt("success");break;case"fire-dom-event":$t(t,"ll-custom",o)}};function St(t){return void 0!==t&&"none"!==t.action}const It={required:{icon:"tune",name:"Required",secondary:"Required options for this card to function",show:!0},actions:{icon:"gesture-tap-hold",name:"Actions",secondary:"Perform actions based on tapping/clicking",show:!1,options:{tap:{icon:"gesture-tap",name:"Tap",secondary:"Set the action to perform on tap",show:!1},hold:{icon:"gesture-tap-hold",name:"Hold",secondary:"Set the action to perform on hold",show:!1},double_tap:{icon:"gesture-double-tap",name:"Double Tap",secondary:"Set the action to perform on double tap",show:!1}}},appearance:{icon:"palette",name:"Appearance",secondary:"Customize the name, icon, etc",show:!1}};let xt=class extends Q{constructor(){super(...arguments),this._initialized=!1}setConfig(t){this._config=t,this.loadCardHelpers()}shouldUpdate(){return this._initialized||this._initialize(),!0}get _name(){var t;return(null===(t=this._config)||void 0===t?void 0:t.name)||""}get _entity(){var t;return(null===(t=this._config)||void 0===t?void 0:t.entity)||""}get _show_warning(){var t;return(null===(t=this._config)||void 0===t?void 0:t.show_warning)||!1}get _show_error(){var t;return(null===(t=this._config)||void 0===t?void 0:t.show_error)||!1}get _tap_action(){var t;return(null===(t=this._config)||void 0===t?void 0:t.tap_action)||{action:"more-info"}}get _hold_action(){var t;return(null===(t=this._config)||void 0===t?void 0:t.hold_action)||{action:"none"}}get _double_tap_action(){var t;return(null===(t=this._config)||void 0===t?void 0:t.double_tap_action)||{action:"none"}}render(){if(!this.hass||!this._helpers)return M``;this._helpers.importMoreInfoControl("climate");const t=Object.keys(this.hass.states).filter((t=>"sun"===t.substr(0,t.indexOf("."))));return M`
      <div class="card-config">
        <div class="option" @click=${this._toggleOption} .option=${"required"}>
          <div class="row">
            <ha-icon .icon=${`mdi:${It.required.icon}`}></ha-icon>
            <div class="title">${It.required.name}</div>
          </div>
          <div class="secondary">${It.required.secondary}</div>
        </div>
        ${It.required.show?M`
              <div class="values">
                <paper-dropdown-menu
                  label="Entity (Required)"
                  @value-changed=${this._valueChanged}
                  .configValue=${"entity"}
                >
                  <paper-listbox slot="dropdown-content" .selected=${t.indexOf(this._entity)}>
                    ${t.map((t=>M` <paper-item>${t}</paper-item> `))}
                  </paper-listbox>
                </paper-dropdown-menu>
              </div>
            `:""}
        <div class="option" @click=${this._toggleOption} .option=${"actions"}>
          <div class="row">
            <ha-icon .icon=${`mdi:${It.actions.icon}`}></ha-icon>
            <div class="title">${It.actions.name}</div>
          </div>
          <div class="secondary">${It.actions.secondary}</div>
        </div>
        ${It.actions.show?M`
              <div class="values">
                <div class="option" @click=${this._toggleAction} .option=${"tap"}>
                  <div class="row">
                    <ha-icon .icon=${`mdi:${It.actions.options.tap.icon}`}></ha-icon>
                    <div class="title">${It.actions.options.tap.name}</div>
                  </div>
                  <div class="secondary">${It.actions.options.tap.secondary}</div>
                </div>
                ${It.actions.options.tap.show?M`
                      <div class="values">
                        <paper-item>Action Editors Coming Soon</paper-item>
                      </div>
                    `:""}
                <div class="option" @click=${this._toggleAction} .option=${"hold"}>
                  <div class="row">
                    <ha-icon .icon=${`mdi:${It.actions.options.hold.icon}`}></ha-icon>
                    <div class="title">${It.actions.options.hold.name}</div>
                  </div>
                  <div class="secondary">${It.actions.options.hold.secondary}</div>
                </div>
                ${It.actions.options.hold.show?M`
                      <div class="values">
                        <paper-item>Action Editors Coming Soon</paper-item>
                      </div>
                    `:""}
                <div class="option" @click=${this._toggleAction} .option=${"double_tap"}>
                  <div class="row">
                    <ha-icon .icon=${`mdi:${It.actions.options.double_tap.icon}`}></ha-icon>
                    <div class="title">${It.actions.options.double_tap.name}</div>
                  </div>
                  <div class="secondary">${It.actions.options.double_tap.secondary}</div>
                </div>
                ${It.actions.options.double_tap.show?M`
                      <div class="values">
                        <paper-item>Action Editors Coming Soon</paper-item>
                      </div>
                    `:""}
              </div>
            `:""}
        <div class="option" @click=${this._toggleOption} .option=${"appearance"}>
          <div class="row">
            <ha-icon .icon=${`mdi:${It.appearance.icon}`}></ha-icon>
            <div class="title">${It.appearance.name}</div>
          </div>
          <div class="secondary">${It.appearance.secondary}</div>
        </div>
        ${It.appearance.show?M`
              <div class="values">
                <paper-input
                  label="Name (Optional)"
                  .value=${this._name}
                  .configValue=${"name"}
                  @value-changed=${this._valueChanged}
                ></paper-input>
                <br />
                <ha-formfield .label=${"Toggle warning "+(this._show_warning?"off":"on")}>
                  <ha-switch
                    .checked=${!1!==this._show_warning}
                    .configValue=${"show_warning"}
                    @change=${this._valueChanged}
                  ></ha-switch>
                </ha-formfield>
                <ha-formfield .label=${"Toggle error "+(this._show_error?"off":"on")}>
                  <ha-switch
                    .checked=${!1!==this._show_error}
                    .configValue=${"show_error"}
                    @change=${this._valueChanged}
                  ></ha-switch>
                </ha-formfield>
              </div>
            `:""}
      </div>
    `}_initialize(){void 0!==this.hass&&void 0!==this._config&&void 0!==this._helpers&&(this._initialized=!0)}async loadCardHelpers(){this._helpers=await window.loadCardHelpers()}_toggleAction(t){this._toggleThing(t,It.actions.options)}_toggleOption(t){this._toggleThing(t,It)}_toggleThing(t,e){const i=!e[t.target.option].show;for(const[t]of Object.entries(e))e[t].show=!1;e[t.target.option].show=i,this._toggle=!this._toggle}_valueChanged(t){if(!this._config||!this.hass)return;const e=t.target;if(this[`_${e.configValue}`]!==e.value){if(e.configValue)if(""===e.value){const t=Object.assign({},this._config);delete t[e.configValue],this._config=t}else this._config=Object.assign(Object.assign({},this._config),{[e.configValue]:void 0!==e.checked?e.checked:e.value});$t(this,"config-changed",{config:this._config})}}static get styles(){return r`
      .option {
        padding: 4px 0px;
        cursor: pointer;
      }
      .row {
        display: flex;
        margin-bottom: -14px;
        pointer-events: none;
      }
      .title {
        padding-left: 16px;
        margin-top: -6px;
        pointer-events: none;
      }
      .secondary {
        padding-left: 40px;
        color: var(--secondary-text-color);
        pointer-events: none;
      }
      .values {
        padding-left: 16px;
        background: var(--secondary-background-color);
        display: grid;
      }
      ha-formfield {
        padding-bottom: 8px;
      }
    `}};t([ot({attribute:!1})],xt.prototype,"hass",void 0),t([st()],xt.prototype,"_config",void 0),t([st()],xt.prototype,"_toggle",void 0),t([st()],xt.prototype,"_helpers",void 0),xt=t([et("rpi-monitor-card-editor")],xt);class Et{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}}const kt="ontouchstart"in window||navigator.maxTouchPoints>0||navigator.maxTouchPoints>0;class Tt extends HTMLElement{constructor(){super(),this.holdTime=500,this.held=!1,this.ripple=document.createElement("mwc-ripple")}connectedCallback(){Object.assign(this.style,{position:"absolute",width:kt?"100px":"50px",height:kt?"100px":"50px",transform:"translate(-50%, -50%)",pointerEvents:"none",zIndex:"999"}),this.appendChild(this.ripple),this.ripple.primary=!0,["touchcancel","mouseout","mouseup","touchmove","mousewheel","wheel","scroll"].forEach((t=>{document.addEventListener(t,(()=>{clearTimeout(this.timer),this.stopAnimation(),this.timer=void 0}),{passive:!0})}))}bind(t,e){if(t.actionHandler)return;t.actionHandler=!0,t.addEventListener("contextmenu",(t=>{const e=t||window.event;return e.preventDefault&&e.preventDefault(),e.stopPropagation&&e.stopPropagation(),e.cancelBubble=!0,e.returnValue=!1,!1}));const i=t=>{let e,i;this.held=!1,t.touches?(e=t.touches[0].pageX,i=t.touches[0].pageY):(e=t.pageX,i=t.pageY),this.timer=window.setTimeout((()=>{this.startAnimation(e,i),this.held=!0}),this.holdTime)},o=i=>{i.preventDefault(),["touchend","touchcancel"].includes(i.type)&&void 0===this.timer||(clearTimeout(this.timer),this.stopAnimation(),this.timer=void 0,this.held?$t(t,"action",{action:"hold"}):e.hasDoubleClick?"click"===i.type&&i.detail<2||!this.dblClickTimeout?this.dblClickTimeout=window.setTimeout((()=>{this.dblClickTimeout=void 0,$t(t,"action",{action:"tap"})}),250):(clearTimeout(this.dblClickTimeout),this.dblClickTimeout=void 0,$t(t,"action",{action:"double_tap"})):$t(t,"action",{action:"tap"}))};t.addEventListener("touchstart",i,{passive:!0}),t.addEventListener("touchend",o),t.addEventListener("touchcancel",o),t.addEventListener("mousedown",i,{passive:!0}),t.addEventListener("click",o),t.addEventListener("keyup",(t=>{13===t.keyCode&&o(t)}))}startAnimation(t,e){Object.assign(this.style,{left:`${t}px`,top:`${e}px`,display:null}),this.ripple.disabled=!1,this.ripple.active=!0,this.ripple.unbounded=!0}stopAnimation(){this.ripple.active=!1,this.ripple.disabled=!0,this.style.display="none"}}customElements.define("action-handler-rpi-monitor",Tt);const Ut=(t,e)=>{const i=(()=>{const t=document.body;if(t.querySelector("action-handler-rpi-monitor"))return t.querySelector("action-handler-rpi-monitor");const e=document.createElement("action-handler-rpi-monitor");return t.appendChild(e),e})();i&&i.bind(t,e)},Dt=(t=>(...e)=>({_$litDirective$:t,values:e}))(class extends Et{update(t,[e]){return Ut(t.element,e),N}render(t){}}),Ft="ifaces",Pt="ux_release",Mt="last_update",Nt="up_time",Ot="fs_total_gb",Rt="fs_free_prcnt",Vt="temperature_c",Ht="show-os-parts",Lt="memory_percent";var jt={version:"Version",invalid_configuration:"Invalid configuration",show_warning:"Show Warning",show_error:"Show Error"},zt={common:jt},Bt=Object.freeze({__proto__:null,common:jt,default:zt}),Gt={version:"Versjon",invalid_configuration:"Ikke gyldig konfiguration",show_warning:"Vis advarsel",show_error:"Vis feil"},Kt={common:Gt},qt=Object.freeze({__proto__:null,common:Gt,default:Kt}),Wt={version:"Version",invalid_configuration:"configuración no válida",show_warning:"Mostrar advertencia",show_error:"Mostrar error"},Yt={common:Wt};const Zt={en:Bt,es:Object.freeze({__proto__:null,common:Wt,default:Yt}),nb:qt};function Jt(t,e="",i=""){const o=(localStorage.getItem("selectedLanguage")||"en").replace(/['"]+/g,"").replace("-","_");let s;try{s=t.split(".").reduce(((t,e)=>t[e]),Zt[o])}catch(e){s=t.split(".").reduce(((t,e)=>t[e]),Zt.en)}return void 0===s&&(s=t.split(".").reduce(((t,e)=>t[e]),Zt.en)),""!==e&&""!==i&&(s=s.replace(e,i)),s}console.info(`%c  RPI-MONITOR-CARD \n%c  ${Jt("common.version")} 1.2.8    `,"color: orange; font-weight: bold; background: black","color: white; font-weight: bold; background: dimgray"),window.customCards=window.customCards||[],window.customCards.push({type:"rpi-monitor-card",name:"RPi Monitor Card",description:"A template custom card for you to create something awesome"});let Xt=class extends Q{constructor(){super(...arguments),this._firstTime=!0,this._sensorAvailable=!1,this._hostname="",this.kREPLACE_WITH_TEMP_UNITS="replace-with-temp-units",this._show_debug=!1,this._cardFullElements={"Storage Use":Rt,Storage:Ot,"Memory Use":Lt,Temperature:Vt,"Up-time":Nt,Updated:Mt,OS:Ht,Model:"rpi_model",Interfaces:Ft},this._cardFullIconNames={Storage:"sd","Storage Use":"file-percent","Memory Use":"memory",Temperature:"thermometer","Up-time":"clock-check-outline",Updated:"update",OS:"linux",Model:"raspberry-pi",Interfaces:""},this.kClassIdIconFSAvail="ico-fs-percent",this.kClassIdIconFSTotal="ico-fs-total",this.kClassIdIconSysTemp="ico-sys-temp",this.kClassIdIconUptime="ico-up-time",this.kClassIdIconUpdated="ico-last-update",this.kClassIdIconOS="ico-*nix",this.kClassIdIconRPiModel="ico-rpi-model",this.kClassIdIconInterfaces="ico-rpi-ifaces",this.kClassIdIconMemoryUsage="ico-memory-percent",this.kClassIdFSAvail="fs-percent",this.kClassIdFSTotal="fs-total",this.kClassIdSysTemp="sys-temp",this.kClassIdUptime="up-time",this.kClassIdUpdated="last-update",this.kClassIdOS="*nix",this.kClassIdRPiModel="rpi-model",this.kClassIdInterfaces="rpi-ifaces",this.kClassIdMemoryUsage="memory-percent",this.kClassIdTempScale="sys-temp-scale",this._cardFullCssIDs={"Storage Use":this.kClassIdFSAvail,Storage:this.kClassIdFSTotal,"Memory Use":this.kClassIdMemoryUsage,Temperature:this.kClassIdSysTemp,"Up-time":this.kClassIdUptime,Updated:this.kClassIdUpdated,OS:this.kClassIdOS,Model:this.kClassIdRPiModel,Interfaces:this.kClassIdInterfaces},this._cardFullIconCssIDs={"Storage Use":this.kClassIdIconFSAvail,Storage:this.kClassIdIconFSTotal,"Memory Use":this.kClassIdIconMemoryUsage,"Up-time":this.kClassIdIconUptime,Updated:this.kClassIdIconUpdated,Temperature:this.kClassIdIconSysTemp,OS:this.kClassIdIconOS,Model:this.kClassIdIconRPiModel,Interfaces:this.kClassIdIconInterfaces},this._cardGlanceElements={"%":Rt,GB:Ot,Mem:Lt,"replace-with-temp-units":Vt,UpTime:Nt,Upd:Mt},this._cardGlanceIconNames={"%":"file-percent",GB:"sd",Mem:"memory","replace-with-temp-units":"thermometer",UpTime:"clock-check-outline",Upd:"update"},this._cardGlanceCssIDs={"%":this.kClassIdFSAvail,GB:this.kClassIdFSTotal,Mem:this.kClassIdMemoryUsage,"replace-with-temp-units":this.kClassIdSysTemp,UpTime:this.kClassIdUptime,Upd:this.kClassIdUpdated},this._cardGlanceIconCssIDs={"%":this.kClassIdIconFSAvail,GB:this.kClassIdIconFSTotal,Mem:this.kClassIdIconMemoryUsage,"replace-with-temp-units":this.kClassIdIconSysTemp,UpTime:this.kClassIdIconUptime,Upd:this.kClassIdIconUpdated},this._circleIconsValueByName={"circle-outline":0,"circle-slice-1":13,"circle-slice-2":25,"circle-slice-3":38,"circle-slice-4":50,"circle-slice-5":63,"circle-slice-6":75,"circle-slice-7":88,"circle-slice-8":100},this._colorUsedSpaceDefault=[{color:"undefined",from:0,to:59},{color:"yellow",from:60,to:84},{color:"red",from:85,to:100}],this._colorTemperatureDefault=[{color:"undefined",from:0,to:59},{color:"yellow",from:60,to:79},{color:"red",from:85,to:100}],this._colorReportPeriodsAgoDefault=[{color:"white",from:0,to:3},{color:"yellow",from:4,to:4},{color:"red",from:5,to:100}],this._colorUsedMemoryDefault=[{color:"red",from:75,to:100},{color:"yellow",from:61,to:74},{color:"",from:0,to:60}],this._colorReleaseDefault=[{color:"red",os:"stretch"},{color:"red",os:"jessie"},{color:"red",os:"wheezy"}]}static async getConfigElement(){return document.createElement("rpi-monitor-card-editor")}static getStubConfig(){return{}}setConfig(t){if(this._showDebug()&&console.log("- setConfig()"),!t||t.show_error)throw new Error(Jt("common.invalid_configuration"));if(null!=t.card_style){const e=t.card_style.toLocaleLowerCase();if("full"!=e&&"glance"!=e)throw console.log("Invalid configuration. INVALID card_style = ["+t.card_style+"]"),new Error("Illegal card_style: value (card_style: "+t.card_style+") must be [full or glance]")}if(null!=t.temp_scale){const e=t.temp_scale.toLocaleLowerCase();if("c"!=e&&"f"!=e)throw console.log("Invalid configuration. INVALID temp_scale = ["+t.temp_scale+"]"),new Error("Illegal temp_scale: value (temp_scale: "+t.temp_scale+") must be [F or C]")}if(!t.entity)throw console.log("Invalid configuration. If no entity provided, you'll need to provide a remote entity"),new Error("You need to associate an entity");t.test_gui&&function(){var t=document.querySelector("home-assistant");if(t=(t=(t=(t=(t=(t=(t=(t=t&&t.shadowRoot)&&t.querySelector("home-assistant-main"))&&t.shadowRoot)&&t.querySelector("app-drawer-layout partial-panel-resolver"))&&t.shadowRoot||t)&&t.querySelector("ha-panel-lovelace"))&&t.shadowRoot)&&t.querySelector("hui-root")){var e=t.lovelace;return e.current_view=t.___curView,e}return null}().setEditMode(!0),this._config=Object.assign({},t),this._updateSensorAvailability()}shouldUpdate(t){if(this._updateSensorAvailability(),t.has("_config"))return!0;if(this.hass&&this._config){const e=t.get("hass");if(e)return e.states[this._config.entity]!==this.hass.states[this._config.entity]}return!0}render(){if(this._showDebug()&&console.log("- render()"),this._config.show_warning)return this.showWarning(Jt("common.show_warning"));if(this._config.show_error)return this.showError(Jt("common.show_error"));const t=this._config.entity?this._config.entity:void 0;if(t&&!this._sensorAvailable){const e="Entity Unavailable: "+t;return this.showWarning(e)}const e=this._config.entity?this.hass.states[this._config.entity]:void 0;if(!t&&!e)return this.showWarning("Entity Unavailable");this._firstTime&&(this._showDebug()&&(console.log("- stateObj:"),console.log(e)),this._startCardRefreshTimer(),this._showDebug()&&(console.log("- 1st-time _config:"),console.log(this._config)),this._firstTime=!1);const i=null==this._config.show_os_age||this._config.show_os_age,o=null==this._config.show_update_age||this._config.show_update_age,s=this._getAttributeValueForKey("fqdn");let n="RPi monitor "+s;const r=1==i?this._getAttributeValueForKey(Pt):"";n=null!=this._config.name_prefix?this._config.name_prefix+" "+s:n,n=null!=this._config.name?this._config.name:n;const a=null==this._config.show_title||this._config.show_title;0==a&&(n="");const l=0==a?"last-heard-full-notitle":"last-heard-full",c=0==a?"last-heard-notitle":"last-heard",h=0==a?"os-name-full-notitle":"os-name-full",d=0==a?"os-name-notitle":"os-name",[u,p]=this._getRelativeTimeSinceUpdate(),m=1==o?u:"";if(this._useFullCard()){const t=this._generateFullsizeCardRows();return M`
        <ha-card
          .header=${n}
          @action=${this._handleAction}
          .actionHandler=${Dt({hasHold:St(this._config.hold_action),hasDoubleClick:St(this._config.double_tap_action)})}
          tabindex="0"
          aria-label=${n}
        >
          <div id="states" class="card-content">
            ${t}
            <div id="card-timestamp" class=${l}>${m}</div>
            <div id="os-name" class=${h}>${r}</div>
          </div>
        </ha-card>
      `}{const t=this._generateGlanceCardRows();return M`
        <ha-card
          .header=${n}
          @action=${this._handleAction}
          .actionHandler=${Dt({hasHold:St(this._config.hold_action),hasDoubleClick:St(this._config.double_tap_action)})}
          tabindex="0"
          aria-label=${n}
        >
          <div class="content">
            ${t}
            <div id="card-timestamp" class=${c}>${m}</div>
            <div id="os-name" class=${d}>${r}</div>
          </div>
        </ha-card>
      `}}_getRelativeTimeSinceUpdate(){var t;const e=this._config.entity?this.hass.states[this._config.entity]:void 0;let i="",o=0;if(null!=this.hass.locale&&null!=e){const s=yt(null===(t=this.hass)||void 0===t?void 0:t.localize,e,this.hass.locale),n=void 0===s?"{unknown}":this.prettyDate(s);i=this._sensorAvailable?n:"{unknown}";const r=n.split(" ")[0];o=r.includes("just")||r.includes("unknown")?0:Number(r)}return[i,o]}prettyDate(t){const e=new Date((t||"").replace(/-/g,"/").replace(/[TZ]/g," ")),i=((new Date).getTime()-e.getTime())/1e3,o=Math.floor(i/86400),s=e.getFullYear(),n=e.getMonth()+1,r=e.getDate();if(isNaN(o)||o<0||o>=31)return s.toString()+"-"+(n<10?"0"+n.toString():n.toString())+"-"+(r<10?"0"+r.toString():r.toString());let a="{unknown}";return 0==o?i<60?a="just now":i<120?a="1 minute ago":i<3600?a=Math.floor(i/60)+" minutes ago":i<7200?a="1 hour ago":i<86400&&(a=Math.floor(i/3600)+" hours ago"):1==o?a="Yesterday":o<7?a=o+" days ago":o<31&&(a=Math.ceil(o/7)+" weeks ago"),a}updated(t){if(this._showDebug()&&console.log("- updated()"),!this._config)return;if(this.hass){const e=t.get("hass");(!e||e&&e.themes!==this.hass.themes)&&function(t,e,i,o){void 0===o&&(o=!1),t._themes||(t._themes={});var s=e.default_theme;("default"===i||i&&e.themes[i])&&(s=i);var n=_t({},t._themes);if("default"!==s){var r=e.themes[s];Object.keys(r).forEach((function(e){var i="--"+e;t._themes[i]="",n[i]=r[e]}))}if(t.updateStyles?t.updateStyles(n):window.ShadyCSS&&window.ShadyCSS.styleSubtree(t,n),o){var a=document.querySelector("meta[name=theme-color]");if(a){a.hasAttribute("default-content")||a.setAttribute("default-content",a.getAttribute("content"));var l=n["--primary-color"]||a.getAttribute("default-content");a.setAttribute("content",l)}}}(this,this.hass.themes,this._config.theme)}this.hass.states[this._config.entity]||this._stopCardRefreshTimer();const e=this.shadowRoot;if(this._sensorAvailable){const t=this._getAttributeValueForKey(Pt),i=this._computeOsReleaseColor(t);if(""!=i){e.getElementById("os-name").style.setProperty("color",i)}if(this._useFullCard())for(const t in this._cardFullCssIDs){const i=this._cardFullCssIDs[t],o=this._cardFullElements[t],s=this._getAttributeValueForKey(o),n=this._getFullCardValueForAttributeKey(o);o==Lt&&console.log("- FULL memory latestValue=["+n+"]");const r=e.getElementById(i);r.textContent=n;const a=this._cardFullIconCssIDs[t],l=e.getElementById(a);if(o==Rt){const t=this._computeFileSystemUsageColor(s);""!=t&&(r.style.setProperty("color",t),l.style.setProperty("color",t))}if(o==Lt){const t=this._computeMemoryUsageColor(n.replace(" %",""));""!=t&&(r.style.setProperty("color",t),l.style.setProperty("color",t))}if(o==Vt){const t=this._computeTemperatureColor(s);""!=t&&(r.style.setProperty("color",t),l.style.setProperty("color",t))}}else for(const t in this._cardGlanceCssIDs){const i=this._cardGlanceCssIDs[t],o=this._cardGlanceElements[t],s=this._getAttributeValueForKey(o),n=this._getGlanceCardValueForAttributeKey(o);o==Lt&&console.log("- GLNC memory latestValue=["+n+"]");const r=e.getElementById(i);r.textContent=n;const a=this._cardGlanceIconCssIDs[t],l=e.getElementById(a);if(o==Rt){const t=this._computeFileSystemUsageColor(s);""!=t&&(r.style.setProperty("color",t),l.style.setProperty("color",t))}if(o==Lt){const t=this._computeMemoryUsageColor(n);""!=t&&(r.style.setProperty("color",t),l.style.setProperty("color",t))}if(o==Vt&&"n/a"!=n){const t=this._computeTemperatureColor(s);""!=t&&(r.style.setProperty("color",t),l.style.setProperty("color",t));e.getElementById(this.kClassIdTempScale).textContent=this._getTemperatureScale()}}}}_handleAction(t){this.hass&&this._config&&t.detail.action&&function(t,e,i,o){var s;"double_tap"===o&&i.double_tap_action?s=i.double_tap_action:"hold"===o&&i.hold_action?s=i.hold_action:"tap"===o&&i.tap_action&&(s=i.tap_action),At(t,e,i,s)}(this,this.hass,this._config,t.detail.action)}showWarning(t){return M` <hui-warning>${t}</hui-warning> `}showError(t){const e=document.createElement("hui-error-card");return e.setConfig({type:"error",error:t,origConfig:this._config}),M` ${e} `}_startCardRefreshTimer(){this._updateTimerID=setInterval((()=>this._handleCardUpdateTimerExpiration()),1e3)}_stopCardRefreshTimer(){null!=this._updateTimerID&&(clearInterval(this._updateTimerID),this._updateTimerID=void 0)}_handleCardUpdateTimerExpiration(){const t=this.shadowRoot;let e=!1;if(null!=(this._config.entity?this.hass.states[this._config.entity]:void 0)){const i=t.getElementById("card-timestamp");if(i){const t=null==this._config.show_update_age||this._config.show_update_age,[o,s]=this._getRelativeTimeSinceUpdate();if(o){let n=o;o.includes("NaN")&&(n="waiting for report...",e=!0),i.textContent=1==t?n:"";const r=this._computeReporterAgeColor(s);""!=r&&null!=r&&i.style.setProperty("color",r)}e&&this._emptyCardValuesWhileWaitingForSensor()}}}_useFullCard(){let t=!0;return this._config&&null!=this._config.card_style&&(t="full"==this._config.card_style.toLocaleLowerCase()),t}_useTempsInC(){let t=!0;return this._config&&null!=this._config.temp_scale&&(t="c"==this._config.temp_scale.toLocaleLowerCase()),t}_logChangeMessage(t){""==this._hostname&&(this._hostname=this._getAttributeValueForKey("host_name"));const e="("+this._hostname+"): "+t;this._showDebug()&&console.log(e)}_updateSensorAvailability(){let t=!1;if(this.hass&&this._config){const e=this._config.entity?this._config.entity:void 0,i=this._config.entity?this.hass.states[this._config.entity]:void 0;if(e||i)try{const e="unavailable"!=this.hass.states[this._config.entity].state;t=this._sensorAvailable!=e,this._sensorAvailable=e}catch(e){this._sensorAvailable=!1,t=!0}else this._sensorAvailable=!1,t=!0}else this._sensorAvailable=!1,t=!0;t&&this._logChangeMessage("* SENSOR available: "+this._sensorAvailable)}_getIconNameForPercent(t){let e="";for(const i in this._circleIconsValueByName){if(t<=this._circleIconsValueByName[i]){e=i;break}}return e}_computeReporterAgeColor(t){let e;return this._colorReportPeriodsAgoDefault.forEach((i=>{t>=i.from&&t<=i.to&&(e=i.color)})),void 0===e&&(e=""),e}_computeTemperatureColor(t){const e=this._config,i=Number(t),o=e.temp_severity?e.temp_severity:this._colorTemperatureDefault;let s;isNaN(i)||o.forEach((e=>{if(i>=e.from&&i<=e.to){s=e.color;const i="_computeTemperatureColor() - value=["+t+"] matched(from="+e.from+", to="+e.to+", color="+s+")";this._showDebug()&&console.log(i)}}));const n="_computeTemperatureColor() - value=["+t+"] returns(color="+s+")";return this._showDebug()&&console.log(n),null==s&&(s=""),s}_computeFileSystemUsageColor(t){const e=this._config,i=Number(t),o=e.fs_severity?e.fs_severity:this._colorUsedSpaceDefault;let s;isNaN(i)||o.forEach((e=>{if(i>=e.from&&i<=e.to){s=e.color;const i="_computeFileSystemUsageColor() - value=["+t+"] matched(from="+e.from+", to="+e.to+", color="+s+")";this._showDebug()&&console.log(i)}}));const n="_computeFileSystemUsageColor() - value=["+t+"] returns(color="+s+")";return this._showDebug()&&console.log(n),null==s&&(s=""),s}_computeMemoryUsageColor(t){const e=this._config,i=Number(t),o=e.memory_severity?e.memory_severity:this._colorUsedMemoryDefault;let s;isNaN(i)||o.forEach((e=>{if(i>=e.from&&i<=e.to){s=e.color;const i="_computeMemoryUsageColor() - value=["+t+"] matched(from="+e.from+", to="+e.to+", color="+s+")";this._showDebug()&&console.log(i)}}));const n="_computeMemoryUsageColor() - value=["+t+"] returns(color="+s+")";return this._showDebug()&&console.log(n),null==s&&(s=""),s}_computeOsReleaseColor(t){const e=this._config;let i;(e.os_age?e.os_age:this._colorReleaseDefault).forEach((e=>{if(t===e.os){i=e.color;const o="_computeOsReleaseColor() - value=["+t+"] matched(os="+e.os+", color="+i+")";this._showDebug()&&console.log(o)}}));const o="_computeTemperatureColor() - value=["+t+"] returns(color="+i+")";return this._showDebug()&&console.log(o),null==i&&(i=""),i}_filterUptime(t){const e=t.split(" ");let i=t;if(i.includes(":")){for(let t=0;t<e.length;t++){const i=e[t];if(i.includes(":")){const o=i.split(":"),s=o[0]+"h:"+o[1]+"m";e[t]=s}}i=e.join(" ")}return i}_getAttributeValueForKey(t){if(!this.hass||!this._config)return"";const e=this._config.entity?this._config.entity:void 0,i=this._config.entity?this.hass.states[this._config.entity]:void 0;if(!e&&!i)return"";if(null==(null==i?void 0:i.attributes))return"";let o="";return t in(null==i?void 0:i.attributes)&&(o=null==i?void 0:i.attributes[t]),o}_emptyCardValuesWhileWaitingForSensor(){const t=this.shadowRoot;if(this._sensorAvailable)if(this._useFullCard())for(const e in this._cardFullCssIDs){const i=this._cardFullCssIDs[e];t.getElementById(i).textContent=""}else for(const e in this._cardGlanceCssIDs){const i=this._cardGlanceCssIDs[e],o=this._cardGlanceElements[e];if(t.getElementById(i).textContent="",o==Vt){t.getElementById(this.kClassIdTempScale).textContent=this._getTemperatureScale()}}}_generateFullsizeCardRows(){const t=[];for(const e in this._cardFullElements){const i=this._cardFullElements[e],o=this._getFullCardValueForAttributeKey(i);let s=this._cardFullIconNames[e];if(i==Rt){const t=this._getAttributeValueForKey(i);s=this._getIconNameForPercent(t)}const n=this._cardFullIconCssIDs[e],r=this._cardFullCssIDs[e];let a="attribute-row";"Model"==e?a="first-short":"Interfaces"==e&&(a="last-short"),t.push(M`
        <div class="${a}">
          <rpi-attribute-row>
            <div class="icon-holder">
              <ha-icon id="${n}" class="attr-icon-full pointer" icon="mdi:${s}"></ha-icon>
            </div>
            <div class="info pointer text-content attr-value">${e}</div>
            <div id="${r}" class="text-content right uom">${o}</div>
          </rpi-attribute-row>
        </div>
      `)}return t}_generateGlanceCardRows(){const t=[];for(const e in this._cardGlanceElements){const i=this._cardGlanceElements[e],o=this._getGlanceCardValueForAttributeKey(i);let s=e;s==this.kREPLACE_WITH_TEMP_UNITS&&(s="n/a"!=o?this._getTemperatureScale():""),i==Lt&&(s="% Mem");let n=this._cardGlanceIconNames[e];i==Rt&&(n=this._getIconNameForPercent(o));const r=this._cardGlanceCssIDs[e],a=this._cardGlanceIconCssIDs[e];let l="units";i==Vt&&(l=this.kClassIdTempScale),t.push(M`
        <div class="attributes" tabindex="0">
          <div>
            <ha-icon id="${a}" class="attr-icon" icon="mdi:${n}"></ha-icon>
          </div>
          <div id="${r}" class="attr-value">${o}</div>
          <div id="${l}" class="uom">${s}</div>
        </div>
      `)}return t}_getTemperatureScale(){const t=1==this._useTempsInC()?"ºC":"ºF",e="_getTemperatureScale() scaleInterp=("+t+")";return this._showDebug()&&console.log(e),t}_getScaledTemperatureValue(t){let e=t;"n/a"!=e&&0==this._useTempsInC()&&(e=(9*parseFloat(t)/5+32).toFixed(1));const i="_getScaledTemperatureValue("+t+") scaleInterp=("+e+")";return this._showDebug()&&console.log(i),e}_getFullCardValueForAttributeKey(t){const e=this._getAttributeValueForKey(t);let i=e;if(t==Lt)i=this._getPercentMemoryUsed()+" %";else if(t==Mt)i=this._getUIDateForTimestamp(e);else if(t==Vt){if(i=this._getScaledTemperatureValue(e),"n/a"!=i){i=i+" "+this._getTemperatureScale()}}else if(t==Ot)i=e+" GB";else if(t==Rt)i=e+" %";else if(t==Nt)i=this._filterUptime(i);else if(t==Ht){i=this._getAttributeValueForKey(Pt)+" v"+this._getAttributeValueForKey("ux_version")}else if(t==Ft){const t=[];e.includes("e")&&t.push("Ether"),e.includes("w")&&t.push("WiFi"),e.includes("b")&&t.push("Bluetooth"),i=t.join(", ")}return i}_getGlanceCardValueForAttributeKey(t){const e=this._getAttributeValueForKey(t);let i=e;return t==Lt?i=this._getPercentMemoryUsed():t==Mt?i=this._getUIDateForTimestamp(e):t==Vt?i=this._getScaledTemperatureValue(e):t==Nt&&(i=this._filterUptime(i)),i}_getUIDateForTimestamp(t){return new Date(t).toLocaleDateString("en-us")}_getPercentMemoryUsed(){const t=this._getAttributeValueForKey("memory"),e=t.size_mb,i=t.free_mb,o=Number(e);return((e-Number(i))/o*100).toFixed(0).toString()}_showDebug(){let t=this._show_debug;return this._config&&null!=this._config.show_debug&&(t=1==t||1==this._config.show_debug),t}static get styles(){return r`
      ha-card {
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        overflow: hidden;
      }
      rpi-attribute-row {
        display: grid;
        flex-direction: row;
        align-items: center;
        height: 40px;
        grid-template-columns: 40px 2fr 3fr;
      }
      #states > * {
        margin: 8px 0px;
      }
      #states > div > * {
        overflow: hidden;
      }
      #states {
        flex: 1 1 0%;
      }
      .right {
        text-align: right;
      }
      .first-short {
        margin: 8px 0px 0px 0px;
        height: 20px;
      }
      .mid-short {
        margin: 0px;
        height: 20px;
      }
      .last-short {
        margin: 0px 0px 8px 0px;
        height: 20px;
      }
      .pointer {
        cursor: pointer;
      }
      .icon-holder {
        align-items: center;
        margin-left: 8px;
      }
      .attr-icon-full {
        color: var(--paper-item-icon-color);
      }
      .attribute-row {
        height: 40px;
      }
      .text-content {
        display: inline;
        line-height: 20px;
      }
      .info {
        white-space: nowrap;
        text-overflow: ellipses;
        overflow: hidden;
        margin-left: 16px;
        flex: 1 0 60px;
      }
      .content {
        display: flex;
        justify-content: space-between;
        padding: 16px 32px 24px 32px;
      }
      .attributes {
        cursor: pointer;
      }
      .attributes div {
        text-align: center;
      }
      .uom {
        color: var(--secondary-text-color);
      }
      .attr-value {
        color: var(--primary-text-color);
      }
      .attr-icon {
        color: var(--paper-item-icon-color);
        margin-bottom: 8px;
      }
      .last-heard-full {
        position: absolute;
        top: 45px;
        right: 30px;
        font-size: 12px;
        color: var(--primary-text-color);
      }
      .last-heard {
        position: absolute;
        top: 55px;
        right: 30px;
        font-size: 12px;
        color: var(--primary-text-color);
      }
      .last-heard-full-notitle {
        position: absolute;
        top: 3px;
        right: 30px;
        font-size: 12px;
        color: var(--primary-text-color);
      }
      .last-heard-notitle {
        position: absolute;
        bottom: 5px;
        right: 90px;
        font-size: 12px;
        color: var(--primary-text-color);
      }
      .os-name-full {
        position: absolute;
        top: 45px;
        left: 30px;
        font-size: 12px;
        color: var(--primary-text-color);
      }
      .os-name {
        position: absolute;
        top: 55px;
        left: 30px;
        font-size: 12px;
        color: var(--primary-text-color);
      }
      .os-name-full-notitle {
        position: absolute;
        top: 3px;
        left: 30px;
        font-size: 12px;
        color: var(--primary-text-color);
      }
      .os-name-notitle {
        position: absolute;
        bottom: 5px;
        left: 90px;
        font-size: 12px;
        color: var(--primary-text-color);
      }
    `}};t([ot({attribute:!1})],Xt.prototype,"hass",void 0),t([st()],Xt.prototype,"_config",void 0),Xt=t([et("rpi-monitor-card")],Xt);export{Xt as RPiMonitorCard};
